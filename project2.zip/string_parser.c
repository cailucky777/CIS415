/*
 * string_parser.c
 *
 *  Created on: Nov 25, 2020
 *      Author: gguan
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "string_parser.h"

#define _GUN_SOURCE

int count_token (char* buf, const char* delim)
{
	//TODO：
	/*
	*	#1.	Check for NULL string
	*	#2.	iterate through string counting tokens
	*		Cases to watchout for
	*			a.	string start with delimeter
	*			b. 	string end with delimeter
	*			c.	account NULL for the last token
	*	#3. return the number of token (note not number of delimeter)
	*/
	if(buf == NULL){
		return -1;
	}

	
	int ct = 0;
	//set a flag for convenience.
	int flag = 1;
	//loop char one by one.
	while(*buf){
		if(flag){
			flag = 0;
			++ct;
		}
		else if (*buf == *delim){
			flag = 1;
		}
		++buf;
	}
	return ct;
}

command_line str_filler (char* buf, const char* delim)
{
	//TODO：
	/*
	*	#1.	create command_line variable to be filled
	*	#2.	use function strtok_r to take out \n character then count
	*			number of tokens with count_token function, set num_token.
	*	#3. malloc memory for token array inside command_line variable
	*			base on the number of tokens.
	*	#4. malloc each index of the array with the length of tokens,
	*			fill array with tokens, and fill last spot with NULL.
	*	#5. return the variable.
	*/
	//1
	command_line var;
	char* save = NULL;
	char* token = NULL;
	char* new_buf = NULL;
	int num_token = 0;


	//2
	new_buf = strtok_r(buf, "\n", &save);
	num_token = count_token(new_buf, delim);
	var.num_token = num_token;

	token = strtok_r(new_buf, delim, &save);


	//3
	var.command_list = (char **)malloc(sizeof( char *) * (num_token + 1));

	//4
	for(int i = 0; i < num_token; i++){
		int length = strlen(token);
		var.command_list[i] = (char *)malloc(sizeof(char) * (length+1));
		strcpy(var.command_list[i],token);
		token = strtok_r(save, delim, &save);
	} 
	
	var.command_list[num_token] = NULL;
	
	//5
	return var;
	
}


void free_command_line(command_line* command)
{
	//TODO：
	/*
	*	#1.	free the array base num_token
	*/
	for(int i = 0; i < command->num_token; i++){
                free(command->command_list[i]);
	}
	free(command->command_list);
        
}
