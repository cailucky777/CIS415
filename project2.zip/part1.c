#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h> 
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>  
#include <sys/stat.h>                       
#include <sys/wait.h>
#include <sys/types.h>
#include "string_parser.h"

int counter(char* filename){
	char* buf = NULL;
	size_t bufsize = 0;
	int sumCommand = 0;
	FILE *fp = fopen(filename, "r");
	while(getline(&buf, &bufsize, fp)!=-1){
		sumCommand++;
	}
	fclose(fp);
	free(buf);
	return sumCommand;

}

int main(int argc,char*argv[])
{

	if (argc != 2)
	{
		printf ("Wrong number of argument\n");
		exit (0);
	}

	FILE *fp = fopen(argv[1], "r");
	if(fp == NULL){
	    fprintf(stderr, "Error, file cannot be opened.\n");
		exit(EXIT_FAILURE);
	}
	char *buf = NULL;
	size_t size = 0;
	
	int commandSize = counter(argv[1]);
	int spawnSize = 0;
	pid_t arrayPid[commandSize];

	
	
	while((getline(&buf, &size, fp)!=-1) && (spawnSize < commandSize)){
		//malloc to save the token.
			command_line commandBuffer = str_filler(buf, " ");
			//spawn the process
			arrayPid[spawnSize] = fork();
			if(arrayPid[spawnSize] < 0 ){
				perror("Error fork.\n");
				exit(EXIT_FAILURE);
			}
			else if(arrayPid[spawnSize]==0){
				int status = execvp(commandBuffer.command_list[0], commandBuffer.command_list);
				if(status == -1){
					fprintf(stderr,"Some error: %s\n", commandBuffer.command_list[0]);
					free_command_line(&commandBuffer);
					free(buf);
					fclose(fp);
					exit(EXIT_FAILURE);
				}
				free_command_line(&commandBuffer);
				free(buf);
				fclose(fp);
			}
		spawnSize++;
		free_command_line(&commandBuffer);
		
	}//while loop end here.

	//wait
	pid_t pw;
	for(int i = 0; i < spawnSize; i++){
		pw = wait(NULL);
	}
	printf("\nDone\n");
	free(buf);
	fclose(fp);
	exit(EXIT_SUCCESS);
	

}//main end here.




