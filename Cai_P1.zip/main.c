/*
 ============================================================================
 Name        : project1.c
 Author      : luying c
 Version     :
 Copyright   : Your copyright notice
 Description :
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "string_parser.h"
#include "command.h"

#define _GNU_SOURCE

int main(int argc, char const *argv[])
{
	char *line_buf = NULL;
	size_t len = 128;
	FILE *fp;
	int mode;

	line_buf = (char *)malloc(sizeof(char)*len);

	command_line buffer;
	command_line small_buffer;


	if(argc == 1){
		 //interactive mode
		mode = 2;
	}
	//case like ./p -f also invalid.
	else if(argc == 2){
		if(!strcmp(argv[1],"-f")){
			fprintf(stderr, "Usage ./pseudo-shell -f <filename>\n");
			exit(EXIT_FAILURE);
		}
		else{
			fprintf(stderr, "Usage ./pseudo-shell -f <filename>\n");
			exit(EXIT_FAILURE);
		}
	}
	else if(argc == 3){
		if(strcmp(argv[1], "-f")){
			fprintf(stderr, "Please enter correct -command such as -f\n");
			exit(EXIT_FAILURE);
		}
		else{
			//open file in here.
			fp = fopen(argv[2], "r");
			if(fp == NULL){
				fprintf(stderr, "Open file failed!!!\n");
				fclose(fp);
				exit(EXIT_FAILURE);
			}
			else{
				mode = 3;
				freopen("output.txt", "w+", stdout);
			}
		}
	}
	else{
		printf("Please use valid Usage\n");
		exit(EXIT_FAILURE);
	}

	while(1){

		//if in interactive mode.
		if(mode == 2){
			printf(">>>");
			getline(&line_buf, &len, stdin);
		}

		//if in file mode.
		if(mode == 3){
			int endd = getline(&line_buf, &len, fp);
			if(endd <= 0){
				break;
			}

		}

		buffer = str_filler(line_buf, ";");

		//big loop
		for(int i = 0; buffer.command_list[i]!= NULL; i++){

			small_buffer = str_filler(buffer.command_list[i], " ");
			
				//small loop
				for(int j = 0; small_buffer.command_list[j]!=NULL; j++){
					//for the ls command.
					if((small_buffer.num_token == 1) && strcmp(small_buffer.command_list[j],"exit")==0){
						free(line_buf);
						free_command_line(&small_buffer);
						free_command_line(&buffer);
						return -1;
					}
					if((small_buffer.num_token == 1) && (strcmp(small_buffer.command_list[j], "ls") != 0)
							&& (strcmp(small_buffer.command_list[j], "pwd") != 0)
							&& (strcmp(small_buffer.command_list[j], "mkdir") != 0)
							&& (strcmp(small_buffer.command_list[j], "cd") != 0)
							&& (strcmp(small_buffer.command_list[j], "cp") != 0)
							&& (strcmp(small_buffer.command_list[j], "mv") != 0)
							&& (strcmp(small_buffer.command_list[j], "rm") != 0)
							&& (strcmp(small_buffer.command_list[j], "cat") != 0)){
						printf("Error! Unrecognized command: %s\n", small_buffer.command_list[j]);
						fflush(stdout);
						break;
						}
					else if((strcmp(small_buffer.command_list[j], "ls") != 0)
							&& (strcmp(small_buffer.command_list[j], "pwd") != 0)
							&& (strcmp(small_buffer.command_list[j], "mkdir") != 0)
							&& (strcmp(small_buffer.command_list[j], "cd") != 0)
							&& (strcmp(small_buffer.command_list[j], "cp") != 0)
							&& (strcmp(small_buffer.command_list[j], "mv") != 0)
							&& (strcmp(small_buffer.command_list[j], "rm") != 0)
							&& (strcmp(small_buffer.command_list[j], "cat") != 0)){
						break;
						}
					else if((strcmp(small_buffer.command_list[j], "ls") == 0)){
						if((small_buffer.num_token == 1) && (strcmp(small_buffer.command_list[j], "ls") == 0)){
							listDir();
							break;
						}
						else if((small_buffer.num_token>1) && (strcmp(small_buffer.command_list[0], "ls")==0)
								&& (strcmp(small_buffer.command_list[j+1], "ls")!=0)){
							printf("Error! Unsupported parameters for command: %s\n", small_buffer.command_list[j]);
							break;
						}
						else if((small_buffer.num_token>1) && (strcmp(small_buffer.command_list[j+1], "ls")==0)){
							printf("Error! Incorrect syntax. No control code found.\n");
							break;
						}
						else if(strcmp(small_buffer.command_list[j+1], "ls")){
							printf("Error! Unsupported parameters for command: %s\n", small_buffer.command_list[j+1]);	
							break;
						}
						else{
							listDir();
							fflush(stdout);
							break;
						}
					}//ls end here

					//for the pwd command.
					if((strcmp(small_buffer.command_list[j], "pwd") == 0)){
						if((small_buffer.num_token == 1) && (strcmp(small_buffer.command_list[j], "pwd") == 0)){
							showCurrentDir();
							fflush(stdout);
							break;
						}
						else if((small_buffer.num_token>1) && (strcmp(small_buffer.command_list[0], "pwd")==0)
								&& (strcmp(small_buffer.command_list[j+1], "pwd")!=0)){
							printf("Error! Unsupported parameters for command: %s\n", small_buffer.command_list[j]);
							break;
						}
						else if((small_buffer.num_token>1) && (strcmp(small_buffer.command_list[j+1], "pwd")==0)){
							printf("Error! Incorrect syntax. No control code found.\n");
							break;
						}
						else if(strcmp(small_buffer.command_list[j+1], "pwd")){
							printf("Error! Unsupported parameters for command: %s\n", small_buffer.command_list[j+1]);
							break;
						}
						else{
							showCurrentDir();
							fflush(stdout);

						}
					}//pwd_ending

					//for mkdir command.
					if((small_buffer.num_token != 2) && (!strcmp(small_buffer.command_list[0], "mkdir"))){
						printf("Error! Usage: mkdir DirectoryName.\n");
						break;
					}
					if((strcmp(small_buffer.command_list[0], "mkdir") == 0)){
						if((small_buffer.num_token == 2) && (strcmp(small_buffer.command_list[0], "mkdir") == 0)){
							makeDir(small_buffer.command_list[j+1]);
							fflush(stdout);
							break;
						}
						else{
							printf("Error! Usage: mkdir DirectoryName.\n");
							break;
						}
					}

					//for the cd command.
					if((small_buffer.num_token != 2) && (!strcmp(small_buffer.command_list[0], "cd"))){
						printf("Error! Usage: cd DirectoryName.\n");
						break;
					}
					if((strcmp(small_buffer.command_list[0], "cd") == 0)){
						if((small_buffer.num_token == 2) && (strcmp(small_buffer.command_list[0], "cd") == 0)){
							changeDir(small_buffer.command_list[j+1]);
							fflush(stdout);
							break;
						}
						else{
							printf("Error! Usage: cd DirectoryName.\n");
							break;
						}
					}//cd end here

					//for the rm command.
					if((small_buffer.num_token != 2) && (!strcmp(small_buffer.command_list[0], "rm"))){
						printf("Error! Usage: rm FileName.\n");
						break;
					}
					if((strcmp(small_buffer.command_list[0], "rm") == 0)){
						if((small_buffer.num_token == 2) && (strcmp(small_buffer.command_list[0], "rm") == 0)){
							deleteFile(small_buffer.command_list[j+1]);
							fflush(stdout);
							break;
						}
						else{
							printf("Error! Usage: rm FileName.\n");
							break;
						}
					}//rm end here.

					//for the cat command.
					if((small_buffer.num_token != 2) && (!strcmp(small_buffer.command_list[0], "cat"))){
						printf("Error! Usage: cat FileName.\n");
						break;
					}
					if((strcmp(small_buffer.command_list[0], "cat") == 0)){
						if((small_buffer.num_token == 2) && (strcmp(small_buffer.command_list[0], "cat") == 0)){
							displayFile(small_buffer.command_list[j+1]);
							fflush(stdout);
							break;
						}
						else{
							printf("Error! Usage: cat FileName.\n");
							break;
						}
					}//cat end here

					//for the cp command.
					if((small_buffer.num_token != 3) && (!strcmp(small_buffer.command_list[0], "cp"))){
						printf("Error! Usage: cp sourcePath destinationPath.\n");
						break;
					}
					if((strcmp(small_buffer.command_list[0], "cp") == 0)){
						if((small_buffer.num_token == 3) && (strcmp(small_buffer.command_list[0], "cp") == 0)){
							copyFile(small_buffer.command_list[j+1], small_buffer.command_list[j+2] );
							fflush(stdout);
							break;
						}
						else{
							printf("Error! Usage: cp sourcePath destinationPath\n");
							break;
						}
					}//cp end here.

					//for the mv command.
					if((small_buffer.num_token != 3) && (!strcmp(small_buffer.command_list[0], "mv"))){
						printf("Error! Usage: mv sourcePath destinationPath.\n");
						break;
					}
					if((strcmp(small_buffer.command_list[0], "mv") == 0)){
						if((small_buffer.num_token == 3) && (strcmp(small_buffer.command_list[0], "mv") == 0)){
							moveFile(small_buffer.command_list[j+1], small_buffer.command_list[j+2] );
							fflush(stdout);
							break;
						}
						else{
							printf("Error! Usage: mv sourcePath destinationPath\n");
							break;
						}
					}
				}//small for loop end here
		}//big for loop for ; end here
	}//while loop end here
	fclose(fp);
	free(line_buf);
	free_command_line(&small_buffer);
	free_command_line(&buffer);

}//sayonara!!
