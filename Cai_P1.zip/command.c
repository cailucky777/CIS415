#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include "command.h"

//for the ls command.
//show the name of files and folders of the current directory.
void listDir(){
	//initialize
	char *path = NULL;
	char *buf = NULL;
	size_t size = 0;

	//copy absolute pathname of the current directory to buf, which len is size.
	path = getcwd(buf, size);

	//open directory and read it.
	DIR *open_dir = opendir(path);
	if(open_dir == NULL){
		printf("could not open current directory.");
		return;
	}

	struct dirent *read_dir;
	while((read_dir = readdir(open_dir))!=NULL){
		write(1, read_dir->d_name, strlen(read_dir->d_name));
		write(1, " ", 1);
	}
	write(1, "\n", 1);
	closedir(open_dir);
	free(path);
	free(buf);

}

//for the pwd command.
void showCurrentDir(){

	char pwd[1024];
	getcwd(pwd, sizeof(pwd));
	write(1, pwd, strlen(pwd));
	write(1, "\n", 1);
	//free(pwd);
}

//for the mkdir command.
void makeDir(char *dirName){

	char pwd[1024];
	getcwd(pwd, sizeof(pwd));
	strcat(pwd, "/");
	strcat(pwd, dirName);
	int status;
	status = mkdir(dirName, 0777);
	if(status != 0){
		write(2, "\nError! Create Fail\n", 22);
		exit(1);
	}
	//free(pwd);
}

//for the cd command.
void changeDir(char *dirName){
	//check current directory and add dirName to the path, then change directory,
	char pwd[1024];
	getcwd(pwd,sizeof(pwd));
	strcat(pwd,"/");
	strcat(pwd, dirName);
	int changed = chdir(dirName);
	if(changed != 0){
		write(2, "Error! directory not changed!\n", 31);
	}
}
//
////for the cp command.
void copyFile(char *sourcePath, char *destinationPath){
	//check sourcefile can opened or not.
	int source = open(sourcePath, O_RDONLY);
	char *s_ret = strrchr(sourcePath, '/');
	char *d_ret = strrchr(destinationPath, '/');
	if(source == -1){
		write(2, "Source cannot open\n", 20);
	}
	else{
		//if sourcePath not contain '/',which means it just a file.
		if(s_ret == NULL){
			//check,if desPath not contain '/'
			if(d_ret == NULL){
				//if destinationPath is not directory
				if(open(destinationPath, O_DIRECTORY) == -1){
					int open_d = open(destinationPath, O_WRONLY| O_CREAT | O_TRUNC, 0777);
					if(open_d == -1){
						close(source);
						write(2, "Error! Open nons/ nond/ notd failed\n", 38);
					}
					else{
						char buffer[1024];
						int line = 0;
						line = read(source, buffer, sizeof(buffer));
						while(line!=0){
							write(open_d, buffer, line);
							line = read(source, buffer, sizeof(buffer));
						}close(open_d);
					}
				}
				//if DestinationPath is a directory.(like source.txt txtfile, txtfile open as a path)
				else{
					char *newDesPath = strcat(destinationPath, "/");
					newDesPath = strcat(destinationPath, sourcePath);
					int open_d = open(newDesPath, O_WRONLY| O_CREAT| O_TRUNC, 0777);
					if(open_d == -1){
						close(source);
						write(2, "Error! Open nons/ nond/ d failed\n", 35);
					}
					else{
						char buffer[1024];
						int line = 0;
						line = read(source, buffer, sizeof(buffer));
						while(line!=0){
							write(open_d, buffer, line);
							line = read(source, buffer, sizeof(buffer));
						}close(open_d);
					}
				}
			}
			//check, if desPath contain '/'
			else{
					//if last string of destinationPath is "/"
					int lens = strlen(destinationPath);
					if(destinationPath[lens-1] == '/'){
						char *newDesPath = strcat(destinationPath, sourcePath);
						int open_d = open(newDesPath, O_WRONLY| O_CREAT| O_TRUNC, 0777);
						if(open_d == -1){
							close(source);
							write(2, "Error! Open nons/ d/ d failed\n", 35);
						}
						else{
							char buffer[1024];
							int line = 0;
							line = read(source, buffer, sizeof(buffer));
							while(line!=0){
								write(open_d, buffer, line);
								line = read(source, buffer, sizeof(buffer));
							}close(open_d);
						}
					}
					//destinationPath contain "/" but not in the last string.
					else{
						char *newDesPath = destinationPath;
						int open_d = open(newDesPath, O_RDWR| O_CREAT| O_TRUNC, 0777);
						if(open_d == -1){
							close(source);
							write(2, "Error! Open nons/ d/middle d failed\n", 36);
						}
						else{
							char buffer[1024];
							int line = 0;
							line = read(source, buffer, sizeof(buffer));
							while(line!=0){
								write(open_d, buffer, line);
								line = read(source, buffer, sizeof(buffer));
							}close(open_d);
						}
					}
			}
		}
		//else if sourcePath contain "/"
		else{
			//check if desPath not contain "/"
			if(d_ret == NULL){
				//check if desPath not a directory.
				if(open(destinationPath, O_DIRECTORY) == -1){
					int open_d = open(destinationPath, O_WRONLY| O_CREAT| O_TRUNC, 0777);
					if(open_d == -1){
						close(source);
						write(2, "Error! Open nons/ nond/ notd failed\n", 38);
					}
					else{
						char buffer[1024];
						int line = 0;
						line = read(source, buffer, sizeof(buffer));
						while(line!=0){
							write(open_d, buffer, line);
							line = read(source, buffer, sizeof(buffer));
						}close(open_d);
					}
				}
				//else(desPath is a directory)
				else{
					char *newDesPath = strcat(destinationPath, s_ret);
					int open_d = open(newDesPath, O_WRONLY| O_CREAT| O_TRUNC, 0777);
					if(open_d == -1){
						close(source);
						write(2, "Error! Open nons/ nond/ d failed\n", 35);
					}
					else{
						char buffer[1024];
						int line = 0;
						line = read(source, buffer, sizeof(buffer));
						while(line!=0){
							write(open_d, buffer, line);
							line = read(source, buffer, sizeof(buffer));
							}close(open_d);
					}
				}

			}

			//check if desPath contain "/"
			else{
				//if last string of destinationPath is "/"
				int lens = strlen(destinationPath);
				if(destinationPath[lens-1] == '/'){
					s_ret++;
					char *newDesPath = strcat(destinationPath, s_ret);
					int open_d = open(newDesPath, O_WRONLY| O_CREAT| O_TRUNC, 0777);
					if(open_d == -1){
						close(source);
						write(2, "Error! Open nons/ d/ d failed\n", 35);
					}
					else{
						char buffer[1024];
						int line = 0;
						line = read(source, buffer, sizeof(buffer));
						while(line!=0){
							write(open_d, buffer, line);
							line = read(source, buffer, sizeof(buffer));
						}close(open_d);
					}
				}
				//destinationPath contain "/" but not in the last string.
				else{
					char *newDesPath = destinationPath;
					int open_d = open(newDesPath, O_RDWR| O_CREAT| O_TRUNC, 0777);
					if(open_d == -1){
						close(source);
						write(2, "Error! Open nons/ d/middle d failed\n", 36);
					}
					else{
						char buffer[1024];
						int line = 0;
						line = read(source, buffer, sizeof(buffer));
						while(line!=0){
							write(open_d, buffer, line);
							line = read(source, buffer, sizeof(buffer));
						}close(open_d);
					}
				}
			}
		}
	}//biggest else end here.
}

//for the mv command.
void moveFile(char *sourcePath, char *destinationPath){

	//open sourcePath,check path can open or not,
	int source = open(sourcePath, O_RDONLY);
	char *s_ret = strrchr(sourcePath, '/');
	char *d_ret = strrchr(destinationPath, '/');
	if(source == -1){
		write(2, "Error! Cannot Open sourcePath\n", 31);
	}
	else{
		//if sourcePath not contain '/',which means it just a file.
		if(s_ret == NULL){
			if(d_ret == NULL){
				//if destinationPath is not directory
				if(open(destinationPath, O_DIRECTORY) == -1){
					copyFile(sourcePath, destinationPath);
					deleteFile(sourcePath);
				}
				else{
					char *newDesPath = strcat(destinationPath, "/");
					newDesPath = strcat(destinationPath, sourcePath);
					copyFile(sourcePath, newDesPath);
					deleteFile(sourcePath);
				}
			}//d_ret == null end here.
			else{
				//if last string of destinationPath is "/"
				int lens = strlen(destinationPath);
				if(destinationPath[lens-1] == '/'){
					char *newDesPath = strcat(destinationPath, sourcePath);
					copyFile(sourcePath, newDesPath);
					deleteFile(sourcePath);
				}
				else{
					char *newDesPath = destinationPath;
					copyFile(sourcePath, newDesPath);
					deleteFile(sourcePath);
				}
			}//d_ret!=null end here.

		}
		//if sourcePath contain "/"
		else{
			//check if desPath not contain "/"
			if(d_ret == NULL){
				//check if desPath not a directory.
				if(open(destinationPath, O_DIRECTORY) == -1){
					copyFile(sourcePath, destinationPath);
					deleteFile(sourcePath);
				}
				else{
					char *newDesPath = strcat(destinationPath, s_ret);
					copyFile(sourcePath, newDesPath);
					deleteFile(sourcePath);
				}
			}//d_ret == null end here.
			else{
				//if last string of destinationPath is "/"
				int lens = strlen(destinationPath);
				if(destinationPath[lens-1] == '/'){
					s_ret++;
					char *newDesPath = strcat(destinationPath, s_ret);
					copyFile(sourcePath, newDesPath);
					deleteFile(sourcePath);
				}
				else{
					char *newDesPath = destinationPath;
					copyFile(sourcePath, newDesPath);
					deleteFile(sourcePath);
				}
			}//d_ret!=null end here.
		}
	}//biggest else end here.

}

//for the rm command.
void deleteFile(char *filename){
	int d = unlink(filename);
	if(d!=0){
		write(2, "Error! Cannot delete!\n", 22);
	}
}

//for the cat command.
void displayFile(char *filename){

	char buffer[1024];
	//open the file.
	int fd = open(filename,O_RDONLY);
	//check if file can open or not.
	if(fd == -1){
		write(2, "Error! Cannot Open\n", 19);
	}
	else{
		int ret = read(fd, buffer, sizeof(buffer));
		while(ret != 0){
			write(STDOUT_FILENO,buffer, ret);
			ret = read(fd, buffer, sizeof(buffer));
		}
	}
	close(fd);
	//free(buffer);


}













