#include "account.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h> 
#include <pthread.h>
#include <dirent.h>
#include <signal.h>
#include <errno.h>
#include <ctype.h>
#include <fcntl.h>  
#include <sys/stat.h>                       
#include <sys/wait.h>
#include <sys/types.h>
#include <math.h>
#include <stdbool.h>
#include "string_parser.h"

void deposit(account* user, double money){
    pthread_mutex_init(&user->ac_lock, NULL);
    pthread_mutex_lock(&user->ac_lock);
    user->balance += money;
    user->transaction_tracker += money;
    pthread_mutex_unlock(&user->ac_lock);
}

void withdraw(account* user, double money){
    pthread_mutex_init(&user->ac_lock, NULL);
    pthread_mutex_lock(&user->ac_lock);
    user->balance -= money;
    user->transaction_tracker += money;
    pthread_mutex_unlock(&user->ac_lock);
}

void transfer_src(account* src, double money){
    pthread_mutex_init(&src->ac_lock, NULL);
    pthread_mutex_lock(&src->ac_lock);
    src->balance -= money;
    src->transaction_tracker += money;
    pthread_mutex_unlock(&src->ac_lock);
}

void transfer_dest(account* dest, double money){
    pthread_mutex_init(&dest->ac_lock, NULL);
    pthread_mutex_lock(&dest->ac_lock);
    dest->balance += money;
    pthread_mutex_unlock(&dest->ac_lock);
}