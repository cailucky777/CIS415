/*
 * PART 1 - Project3 / CIS415
 * 5/26/2021
 * Luying Cai 
 * 
 * This part for counting the total balance of each account.
 */
#include "account.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h> 
#include <pthread.h>
#include <dirent.h>
#include <signal.h>
#include <errno.h>
#include <ctype.h>
#include <fcntl.h>  
#include <sys/stat.h>                       
#include <sys/wait.h>
#include <sys/types.h>
#include <math.h>
#include <stdbool.h>
#include "string_parser.h"

//pthread type
pthread_cond_t   cond;
pthread_mutex_t my_lock;
pthread_cond_t lock_update;
pthread_mutex_t lock_out;
pthread_barrier_t barrier;
//initial 
account* user = NULL;
command_line* big_buffer = NULL;

//int type global variable.
int sizeUser=0, total_line=0,total_user_line=0, trans_Line=0;
int each_range=0;
int update_sum = 0;
int protect = 0;
bool flag_to_update = 0;

void* update_balance (void* args);
void* process_transaction (void* args);
//helper for numsOfLine

int numsOfLine(char *filename){
    FILE *fp = fopen(filename, "r"); 
    int counter = 0;
    char *buf = NULL; 
    size_t bufsize = 0;
    while (getline(&buf, &bufsize, fp) != -1) {
        counter++; 
    }
    fclose(fp); 
    free(buf);
    return counter;
}



//main function for output file.
int main(int argc,char*argv[])
{
    char *line_buf = NULL;
	size_t line_buf_size = 0;

    if (argc != 2)
	{
		printf ("Wrong number of argument\n");
		exit (0);
	}
    FILE *fp = fopen(argv[1], "r");
	if(fp == NULL){
	    fprintf(stderr, "ERROR 1, input file cannot be opened.\n");
	}

    total_line = numsOfLine(argv[1]);

    //read the first line and get the size of users accounts and move the pointer to the next line.
    getline(&line_buf, &line_buf_size, fp);
    sizeUser = atoi(line_buf);

    //getting the number of accounts line.
    total_user_line = sizeUser * 5;

    trans_Line = total_line - 1 - total_user_line;

    //save the user info
    user = malloc(sizeUser*sizeof(account));
    //user[sizeUser];
    for(int i = 0; i < sizeUser; i++){
        user[i].transaction_tracker= 0;
        pthread_mutex_init(&user[i].ac_lock, NULL);
    }

   
    int inner = 0;
    for(int i=0; i < total_user_line; i++){
        getline(&line_buf, &line_buf_size, fp);
        //printf("line begining: %s\n", line_buf); 
        inner = (i % 5);
        switch(inner){
            case 1:
            {
                sscanf(line_buf, "%s", user[(int)floor((i)/5)].account_number);
                //printf("让我看看我的account对不对： %s\n",user[(int)floor((i)/5)].account_number);
                break;
    
            }
            case 2:
            {
                sscanf(line_buf, "%s", user[(int)floor((i-1)/5)].password);
                //printf("password: %s\n",user[(int)floor((i)/5)].password);
                break;
            }
            case 3:
            {
                sscanf(line_buf, "%lf", &user[(int)floor((i-1)/5)].balance);
                //printf("balance: %lf\n",user[(int)floor((i)/5)].balance);
                break;
            }
            case 4:
            {
                sscanf(line_buf, "%lf", &user[(int)floor((i-1)/5)].reward_rate);
                //printf("reward_rate: %lf\n",user[(int)floor((i)/5)].reward_rate);
                break;
            }
        } 
    }

    //make an array of command_line to save each line.
    big_buffer = malloc(trans_Line*sizeof(command_line));
    for(int i = 0; i < (trans_Line); i++){
        getline(&line_buf, &line_buf_size, fp);
        big_buffer[i] = str_filler(line_buf, " ");
        //printf("this is for line[0]: %s\n",big_buffer[i].command_list[0]);
    }



    //start thread.
    pthread_t tid[10];
    pthread_mutex_init(&my_lock,NULL);
    pthread_cond_init(&lock_update, NULL);
    pthread_mutex_init(&lock_out, NULL);
    pthread_cond_init(&cond,NULL);
    pthread_barrier_init(&barrier, NULL, 11);
    pthread_attr_t attr;
    pthread_attr_init(&attr);

    for(int thread = 0; thread < 10; thread++){
        printf("Before Thread %d.....\n", thread);
        each_range = trans_Line/10;
        int ret = pthread_create(&tid[thread],&attr, process_transaction, (void*)(big_buffer+thread*each_range));
        if(ret!=0){
            printf("pthread_create filed in %d....\n", thread);
        }
    }
    
     //bank
    pthread_t bank;
    //printf("flag now: %d\n", flag_to_update);
    pthread_create(&bank, NULL, update_balance, (void*)user);

    for(int i = 0; i < 10; i++){
        pthread_join(tid[i],NULL);  
    }


    for(int i=0; i< trans_Line; i++){
        free_command_line(&(big_buffer[i]));
    }
    free(big_buffer);
    free(user);
    fclose(fp);
    free(line_buf);

}
//process
void* process_transaction (void* args)
{

    command_line* info_Line;
    info_Line = (command_line*)args;

    for(int j=0; j<each_range; j++)
    {
        //printf("%s\n",*(info_Line->command_list));
        //存款
        pthread_barrier_wait(&barrier);

        pthread_mutex_lock(&my_lock);
        update_sum++;
        printf("updating number: %d\n", update_sum);
        if(update_sum % 5 == 0 && update_sum != 0)
        {   
            flag_to_update = 1;
            printf("flag now: %d\n", flag_to_update);
            pthread_cond_signal(&lock_update);
            pthread_cond_wait(&cond, &my_lock);
            pthread_mutex_unlock(&my_lock);
        }
        else {
            pthread_mutex_unlock(&my_lock);
        }

        if(strcmp(info_Line[j].command_list[0], "D") == 0){
            for(int id = 0;id < sizeUser; id++){
                if((strcmp(info_Line[j].command_list[1], user[id].account_number)==0) && (strcmp(info_Line[j].command_list[2], user[id].password)==0)){
                        deposit(&user[id], atof(info_Line[j].command_list[3]));
                    }
            }
        }
        //取款
        else if(strcmp(info_Line[j].command_list[0], "W")==0){
            for(int id = 0; id < sizeUser; id++){
                if((strcmp(info_Line[j].command_list[1], user[id].account_number)==0) && (strcmp(info_Line[j].command_list[2], user[id].password)==0)){
                    withdraw(&user[id], atof(info_Line[j].command_list[3]));
                }
            }
        }
        //transfer funds
        else if(strcmp(info_Line[j].command_list[0], "T")==0){ 
            bool srcValid = false;
            bool destValid = false;
            int srcUserId = -1; 
            int destUserId = -1;
            for(int id = 0; id < sizeUser; id++){
                if((strcmp(info_Line[j].command_list[1], user[id].account_number)==0) && (strcmp(info_Line[j].command_list[2], user[id].password)==0)){
                    srcValid = true;
                    srcUserId = id;
                }
                else if(strcmp(info_Line[j].command_list[3], user[id].account_number)==0){
                    destValid = true;
                    destUserId = id;

                }
            }
            if(srcValid && destValid){
                transfer_src(&user[srcUserId], atof(info_Line[j].command_list[4]));
                transfer_dest(&user[destUserId], atof(info_Line[j].command_list[4]));
            }
        } 
    
    }
    //printf("------------end getting-----------\n");
}
/*
 * This function for update_balance.
 * balance += (rate * tracker).
 * 
 */
void* update_balance (void* args){

    pthread_barrier_wait(&barrier);
    while(1){
        pthread_cond_wait(&lock_update,&my_lock);
        account *user;
        user = (account*)args;
        for(int i = 0; i < sizeUser; i++){
            //pthread_mutex_lock(&user[i].ac_lock);
            user[i].balance += user[i].reward_rate * user[i].transaction_tracker;
            printf("%d balance:  %.2lf \n", i, user[i].balance);
            //sprintf(user[i].out_file, "account%d.txt", i);
            //pthread_mutex_unlock(&user[i].ac_lock);
        }
        flag_to_update = 0;
        pthread_cond_broadcast(&cond);
    }
}
