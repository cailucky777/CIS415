/*
 * PART 1 - Project3 / CIS415
 * 5/26/2021
 * Luying Cai 
 * 
 * This part for counting the total balance of each account.
 */
#include "account.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h> 
#include <pthread.h>
#include <dirent.h>
#include <signal.h>
#include <errno.h>
#include <ctype.h>
#include <fcntl.h>  
#include <sys/stat.h>                       
#include <sys/wait.h>
#include <sys/types.h>
#include <math.h>
#include <stdbool.h>
#include "string_parser.h"

//initial 
account* user = NULL;
command_line* big_buffer = NULL;
int sizeUser, total_line,total_user_line, trans_Line;

void* update_balance (account *user);
void* process_transaction (command_line* info_Line);
//helper for numsOfLine

int numsOfLine(char *filename){
    FILE *fp = fopen(filename, "r"); 
    int counter = 0;
    char *buf = NULL; 
    size_t bufsize = 0;
    while (getline(&buf, &bufsize, fp) != -1) {
        counter++; 
    }
    fclose(fp); 
    free(buf);
    return counter;
}



//main function for output file.
int main(int argc,char*argv[])
{
    char *line_buf = NULL;
	size_t line_buf_size = 0;

    if (argc != 2)
	{
		printf ("Wrong number of argument\n");
		exit (0);
	}
    FILE *fp = fopen(argv[1], "r");
	if(fp == NULL){
	    fprintf(stderr, "ERROR 1, input file cannot be opened.\n");
	}

    total_line = numsOfLine(argv[1]);

    //read the first line and get the size of users accounts and move the pointer to the next line.
    getline(&line_buf, &line_buf_size, fp);
    sizeUser = atoi(line_buf);

    //getting the number of accounts line.
    total_user_line = sizeUser * 5;

    trans_Line = total_line - 1;
    //make an array of command_line to save each line.
    big_buffer = malloc(trans_Line*sizeof(command_line));

    for(int i = 0; i < trans_Line; i++){
        getline(&line_buf, &line_buf_size, fp);
        big_buffer[i] = str_filler(line_buf, " ");
        //printf("this is for line[0]: %s\n",big_buffer[i].command_list[0]);
    }
    //save the user info
    user = malloc(sizeUser*sizeof(account));
    //user[sizeUser];
    for(int i = 0; i < sizeUser; i++){
        user[i].transaction_tracker= 0;
    }
   
    int inner = 0;
    for(int i=0; i < total_user_line; i++){
        inner = i % 5; 
        switch(inner){
            case 1:
            {
                sscanf(big_buffer[i].command_list[0], "%s", user[(int)floor((i)/5)].account_number);
                //printf("让我看看我的account对不对： %s\n",user[(int)floor((i)/5)].account_number);
                break;
    
            }
            case 2:
            {
                sscanf(big_buffer[i].command_list[0], "%s", user[(int)floor((i-1)/5)].password);
                //printf("password: %s\n",user[(int)floor((i)/5)].password);
                break;
            }
            case 3:
            {
                sscanf(big_buffer[i].command_list[0], "%lf", &user[(int)floor((i-1)/5)].balance);
                //printf("balance: %lf\n",user[(int)floor((i)/5)].balance);
                break;
            }
            case 4:
            {
                sscanf(big_buffer[i].command_list[0], "%lf", &user[(int)floor((i-1)/5)].reward_rate);
                //printf("reward_rate: %lf\n",user[(int)floor((i)/5)].reward_rate);
                break;
            }
        }  
    }

    process_transaction(big_buffer);
    
    update_balance (user);
    
    for(int i=0; i< trans_Line; i++){
        free_command_line(&(big_buffer[i]));
    }
    free(big_buffer);
    free(user);
    fclose(fp);
    free(line_buf);
}

/*
 * This function for different type of transaction.
 * After the account info, there are bunch of transaction in ther file.
 * And there are FOUR types of transaction required. 
 * "T":src_account | password | dest_account | transfer_amount
 * "C":account_num | password
 * "D":account_num | password | amount
 * "W":account_num | password | amount
 */
void* process_transaction (command_line* info_Line)
{
    //我要开始搞transaction了
    for(int j=total_user_line; j<trans_Line; j++){
        //存款
        //printf("51: %s\n", info_Line[j].command_list[0]);
        if(strcmp(info_Line[j].command_list[0], "D") == 0){
            //检查src账户一致and检查密码一致
            for(int id = 0;id < sizeUser; id++){
                if((strcmp(info_Line[j].command_list[1], user[id].account_number)==0) && (strcmp(info_Line[j].command_list[2], user[id].password)==0)){
                        //将钱转type然后累加到tracker里面。
                        user[id].transaction_tracker = user[id].transaction_tracker + atof(info_Line[j].command_list[3]);
                        //更新balance
                        user[id].balance += atof(info_Line[j].command_list[3]);
                    }
            }
        }
        //取款
            else if(strcmp(info_Line[j].command_list[0], "W")==0){
                //检查src账户一致and检查密码一致
                for(int id = 0; id < sizeUser; id++){
                    if((strcmp(info_Line[j].command_list[1], user[id].account_number)==0) && (strcmp(info_Line[j].command_list[2], user[id].password)==0)){
                        //将钱转type然后累加到tracker里面。
                        user[id].transaction_tracker = user[id].transaction_tracker + atof(info_Line[j].command_list[3]);
                        //更新balance，给它减了！
                        user[id].balance -= atof(info_Line[j].command_list[3]);
                    }
                }
            }
        //transfer funds
            else if(strcmp(info_Line[j].command_list[0], "T")==0){ 
                //检查src账户密码，检查dest账户密码是否一致,利用flag
                bool srcValid = false;
                bool destValid = false;
                int srcUserId = -1; 
                int destUserId = -1;
                for(int id = 0; id < sizeUser; id++){
                    if((strcmp(info_Line[j].command_list[1], user[id].account_number)==0) && (strcmp(info_Line[j].command_list[2], user[id].password)==0)){
                        srcValid = true;
                        srcUserId = id;
                    }
                    else if(strcmp(info_Line[j].command_list[3], user[id].account_number)==0){
                        destValid = true;
                        destUserId = id;

                    }
                }
                if(srcValid && destValid){
                    user[srcUserId].transaction_tracker = user[srcUserId].transaction_tracker + atof(info_Line[j].command_list[4]);
                    user[srcUserId].balance -= atof(info_Line[j].command_list[4]);
                    user[destUserId].balance += atof(info_Line[j].command_list[4]);
                }
            } 

    }
}
/*
 * This function for update_balance.
 * balance += (rate * tracker).
 * 
 */
void* update_balance (account *user){
    for(int i = 0; i < sizeUser; i++){
        //printf("%d balance before:  %.2lf \n", i, user[i].balance);
        user[i].balance += user[i].reward_rate * user[i].transaction_tracker;
        //printf("%d rate : %f\n", i, user[i].reward_rate);
        printf("%d balance after:  %.2lf \n", i, user[i].balance);
        //printf("%d tracker:  %.2lf \n", i, user[i].transaction_tracker);
    }
}
