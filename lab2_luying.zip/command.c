#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include "command.h"

void lfcat(){
	//initialize
	char *path = NULL;
	char *buf = NULL;
	size_t size = 0;
	char *line = NULL;

	//copy absolute pathname to array pointed to by buf.
	path = getcwd(buf, size);

	//open directory and read it.
	DIR *open_dir = opendir(path);
	if(open_dir == NULL){
		printf("could not open current directory.");
		return;
	}

	struct dirent *read_dir;
	freopen("output.txt", "w+", stdout);

	while((read_dir = readdir(open_dir))!=NULL){
		//check if directory can be opened.
		FILE *fp;
		fp = fopen(read_dir->d_name, "r");
		
		if(strcmp(read_dir->d_name, ".")&&strcmp(read_dir->d_name, "..")&&strcmp(read_dir->d_name, "output.txt")&&strcmp(read_dir->d_name, "lab2.o")&&strcmp(read_dir->d_name, "command.h")&&strcmp(read_dir->d_name, "command.c")&&strcmp(read_dir->d_name, "string_parser.c")&&strcmp(read_dir->d_name, "string_parser.h")&&strcmp(read_dir->d_name, "lab2.exe")&&strcmp(read_dir->d_name, "Makefile")&&strcmp(read_dir->d_name, "string_parser.o")&&strcmp(read_dir->d_name, "command.o")&&strcmp(read_dir->d_name, "lab2.c")){

			if(fp != NULL){
	
				write(1, read_dir->d_name, strlen(read_dir->d_name));
				write(1, "\n", 1);
				size_t line_read = 0;
				while((line_read = getline(&line, &size, fp))!= -1){
					write(1, line, line_read);
				}

				write(1,"\n", 1);
				for(int i= 0; i < 80; i++){
					write(1, "-", 1);
				}
				write(1,"\n", 1);
			
			}
			
		}else{//do nothing
		     }fclose(fp);
		
	}
	free(line);
	free(path);
	free(buf);
	free(read_dir);
	closedir(open_dir);


}

