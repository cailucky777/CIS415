/*
 * lab2.c
 *
 *  Created on: Nov 25, 2020
 *      Author: Guan, Xin
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "string_parser.h"
#include "command.h"

#define _GNU_SOURCE

int main(int argc, char const *argv[])
{
	//declear line_buffer
	size_t len = 128;
	char* line_buf = malloc (len);
	char *token = NULL;

	command_line varb;

	//loop until the file is over
	while (1)
	{

		printf(">>>");
		getline(&line_buf, &len, stdin);

		varb = str_filler(line_buf, ";");
		for(int i = 0; varb.command_list[i]!= NULL; i++){
			if(strcmp(varb.command_list[i], "exit")==0){
				return -1;;
			}
			if(strcmp(varb.command_list[i], "lfcat")){
				printf("Error: Unrecognized command!\n");
			}
			else{
				lfcat();
				free(line_buf);
				free_command_line(&varb);
				return 1;
			}
		}
	}
	//free(line_buf);
	//free(token);
	//free(varb.command_list);

}

