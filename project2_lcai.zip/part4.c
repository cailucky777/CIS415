#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h> 
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>  
#include <sys/stat.h>                       
#include <sys/wait.h>
#include <sys/types.h>
#include "string_parser.h"

int counter(char* filename){
	char* buf = NULL;
	size_t bufsize = 0;
	int sumCommand = 0;
	FILE *fp = fopen(filename, "r");
	while(getline(&buf, &bufsize, fp)!=-1){
		sumCommand++;
	}
	fclose(fp);
	free(buf);
	return sumCommand;
}

/*
*This function is for getting each child process's info.
*Credit: https://stackoverflow.com/questions/33266678/how-to-extract-information-from-the-content-of-proc-files-on-linux-using-c.
*/

void fakeTop(pid_t pid){
	char fp[1000];
    sprintf(fp, "/proc/%d/stat", pid);
    FILE *f = fopen(fp, "r");

	printf("\nPID = %d\n",pid);

	char comm[1000];
    char state;
    int ppid;
	int session;
	int tpgid;
	unsigned long cminflt;
	unsigned long utime;
	long int nice;
    long int num_threads;

	fscanf(f, "%s %c %d %d %d %lu %lu %ld %ld", comm, &state, &ppid, &session, &tpgid, &cminflt, &utime, &nice, &num_threads);
    printf("process ID = %s\n", comm);
    printf("process state = %c\n", state);
    printf("parent pid = %d\n", ppid);
	printf("process group ID of the process = %d\n", session);
	printf("The controlling terminal of the process = %d\n", tpgid);
	printf("The number of minor faults the process has made which have not required loading a memory page from disk = %lu\n", cminflt);
	printf("The number of major faults that the process's waited-for children have made = %lu\n", utime);
	printf(" The nice value = %ld\n", nice);
	printf("Number of threads in this process = %ld\n", num_threads);
    fclose(f);

}


void signaler(pid_t *ppool, int size, int sig){
	sleep(2);
	for(int i = 0; i < size; i++){
		fprintf(stdout,"Parent process: <%d> - Sending signal: <%s> to child process: <%d> \n", getpid(), strsignal(sig), ppool[i]);
		kill(ppool[i], sig);//send signal to the child processes.
	}

}
/*
* roundRobin fucntion is for using time slice to handle each process.
* using p_dead to track each process, if p_dead equal to commandsize, then all process end.
* using GODIE as flag to make sure that after process end, will not loop again.
* using WNOHANG | WUNTRACED to control waitpid, WUNTRACED for if child process which stop, then return immi.
* using WIFEXITED to control status if exit. 
*/
int roundRobin(sigset_t set, int setsig, pid_t *pid, int commandSize){
	int status; //子进程退出时的信息
	int p_index = 0;
	int p_dead = 0;
	int GODIE = 666;
	pid_t current;
	while(1){
		if(p_index == 0){
			if (p_dead == commandSize){
				sleep(1);
				printf("\n --------CHILD PROCESS ALL DEAD！！！！------\n");
				sleep(1);
				printf("\n ------------------FINISHED---------------------\n");
				break;
			}
		}

		current = pid[p_index];
		if(current != GODIE){
			waitpid(current, &status, WNOHANG | WUNTRACED );
			if(WIFEXITED(status)){
				sleep(2);
				printf("\n Normal exit : <%d>\n", current);
				p_dead ++;
				pid[p_index] = GODIE;
				
			}
			else{
				alarm(2);
				printf("\nAlarm setting.....\n");
				printf("\n<%d> count.....\n", current);
				fakeTop(current);
				kill(current, SIGCONT);
				if(sigwait(&set, &setsig)==0){
					kill(current, SIGSTOP);
				};
			}
		}
		p_index = (p_index + 1) % commandSize;
	}
	return 0;
}


int main(int argc,char*argv[])
{

	if (argc != 2)
	{
		printf ("Wrong number of argument\n");
		exit (0);
	}

	FILE *fp = fopen(argv[1], "r");
	if(fp == NULL){
	    fprintf(stderr, "Error, file cannot be opened.\n");
	}
	char *buf = NULL;
	size_t size = 0;
	
	int commandSize = counter(argv[1]);
	int spawnSize = 0;
	pid_t arrayPid[commandSize];



	//initial signal set
	sigset_t set;
	int sig;
	
	//initial a signal set.
	sigemptyset(&set);
	//add SIGUSR1 into the signal set.
	sigaddset(&set, SIGUSR1);
	//add set in signal_block set.
	sigprocmask(SIG_BLOCK, &set, NULL);

	while((getline(&buf, &size, fp)!=-1) && (spawnSize < commandSize)){
		//malloc to save the token.
			command_line commandBuffer = str_filler(buf, " ");
			//spawn the process
			arrayPid[spawnSize] = fork();
			if(arrayPid[spawnSize] < 0 ){
				perror("Error parent fork.\n");
				exit(EXIT_FAILURE);
			}
			else if(arrayPid[spawnSize]==0){//child process
				fprintf(stdout, "\nChild Process: <%d> - Waiting for SIGUSR1...\n",getpid());
				sigwait(&set, &sig);
				sleep(2);
				fprintf(stdout, "\nChild Process: <%d> - Received signal: SIGUSR1 - Calling exec()\n",getpid());
				sleep(3);
				int status = execvp(commandBuffer.command_list[0], commandBuffer.command_list);
				sleep(4);
				if(status == -1){
					fprintf(stderr,"\nChild process: <%d> -failed to execute program [%s]. \n", getpid(),commandBuffer.command_list[0]);
					free_command_line(&commandBuffer);
					free(buf);
					fclose(fp);
					exit(EXIT_FAILURE);
				}
				sleep(3);
			}					
		spawnSize++;
		free_command_line(&commandBuffer);
	}//while loop end here.

	//sending signals
    sigaddset(&set, SIGALRM);
    sigprocmask(SIG_BLOCK, &set, NULL);
	
	sleep(1);
	printf("\n---------------Sending SIGUSR1-------------------\n");
	signaler(arrayPid, commandSize, SIGUSR1);
	sleep(3);
	printf("\n---------------Sending SIGSTOP-------------------\n");
	signaler(arrayPid, commandSize, SIGSTOP);
	sleep(3);
	
    //to check which child process is still live. go to for loop to keep execute. 
	printf("\n---------------------CHECK IS ANY CHILD STILL ALIVE------------------------\n");
	roundRobin(set, sig, arrayPid, commandSize);

	
	
	//wait
	free(buf);
	fclose(fp);
	

}//main end here.




